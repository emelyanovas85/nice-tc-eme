package impl;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * Используется для хранения тестовых параметров тест-кейса из Jira.
 */
public class Parameters {
    private final Map<String, String> parametersMap;

    public Parameters(Map<String, String> m) {
        parametersMap = Collections.unmodifiableMap(m);
    }

    public String get(String parameterName) {
        return parametersMap.get(parameterName);
    }

    public String getOrDefault(String parameterName, String defaultValue) {
        return parametersMap.getOrDefault(parameterName, defaultValue);
    }

    public Map<String, String> getParametersMap() {
        return parametersMap;
    }

    public boolean has(String parameterName) {
        return parametersMap.containsKey(parameterName);
    }

    public int parameterCount() {
        return parametersMap.size();
    }

    @JsonIgnore
    public boolean isEmpty() {
        return parametersMap.isEmpty();
    }

    public List<String> parameterNames() {
        return new ArrayList<>(parametersMap.keySet());
    }
}
