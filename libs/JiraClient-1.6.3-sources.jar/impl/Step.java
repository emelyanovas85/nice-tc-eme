package impl;

import java.util.Collections;
import java.util.List;

/**
 * Используется для предоставления информации о шаге из тест кейса.
 * Основным отличием от {@link dto.testCase.StepDTO} это пред обработка строк.
 * Подробнее {@link mappers.StepMapper}
 */
public class Step {
    private final int stepNumber;
    private final String description;
    private final List<String> expectedResults;
    private final Parameters parameters;

    public Step(int stepNumber, String description, List<String> expectedResults, Parameters parameters) {
        this.stepNumber = stepNumber;
        this.description = description;
        this.expectedResults = Collections.unmodifiableList(expectedResults);
        this.parameters = parameters;
    }

    public int getStepNumber() {
        return stepNumber;
    }

    public String getDescription() {
        return description;
    }

    public List<String> getExpectedResults() {
        return expectedResults;
    }

    public Parameters getParameters() {
        return parameters;
    }
}
