package impl;

import java.util.Collections;
import java.util.List;

public class TestCase {
    private final String id;
    private final int version;
    private final String displayName;
    private final List<Step> steps;
    private final Parameters parameters;
    private final List<TestData> testData;
    private final String precondition;
    private final String priority;

    public TestCase(String id, int version, String displayName, List<Step> steps, Parameters parameters, List<TestData> testData, String precondition, String priority) {
        this.id = id;
        this.version = version;
        this.displayName = displayName;
        this.steps = Collections.unmodifiableList(steps);
        this.parameters = parameters;
        this.testData = Collections.unmodifiableList(testData);
        this.precondition = precondition;
        this.priority = priority;
    }

    public String getId() {
        return id;
    }

    public boolean isParameterized() {
        return !testData.isEmpty();
    }

    public String getProjectName() {
        return id.split("-")[0];
    }

    public int getVersion() {
        return version;
    }

    public String getName() {
        return displayName;
    }

    public List<Step> getSteps() {
        return steps;
    }

    public Parameters getParameters() {
        return parameters;
    }

    public List<TestData> getTestData() { return testData; }

    public String getPrecondition() {
        return precondition;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getPriority() {
        return priority;
    }
}
