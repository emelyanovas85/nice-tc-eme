package jira.api.testCaseAPI;

import com.fasterxml.jackson.core.type.TypeReference;
import dto.testCase.VersionDTO;
import impl.Parameters;
import impl.Step;
import impl.TestCase;
import impl.TestData;
import jira.api.impl.JiraTestCaseImpl;
import jiraClient.JiraClientSingleton;

import java.io.File;
import java.nio.file.Path;
import java.util.List;
import java.util.stream.Stream;

public interface JiraTestCaseAPI {

    static JiraTestCaseAPI getDefault() {
        return new JiraTestCaseImpl(JiraClientSingleton.getJiraClient());
    }

    /**
     * Служит для полчения json тест-кейса
     *
     * @param testCaseID идентификатор тест-кейса из Jira (example: "VPEPVV-T803", "ASPPODDELTA-T1082")
     * @param fields     имена полей тест кейса
     * @return body.string, если body.string == null, то пустая строка
     */
    String requestToJira(String testCaseID, String... fields);

    /**
     * Служит для предоставления данных о тест-кейсе {@link TestCase}
     *
     * @param testCaseID идентификатор тест-кейса из Jira (example: "VPEPVV-T803", "ASPPODDELTA-T1082")
     */
    TestCase getTestCase(String testCaseID);

    /**
     * Служит для предоставления данных о тест-кейсе {@link TestCase}
     *
     * @param testCaseID идентификатор тест-кейса из Jira (example: "VPEPVV-T803", "ASPPODDELTA-T1082")
     * @param version    версия тест-кейса из Jira (example: "1")
     */
    TestCase getTestCase(String testCaseID, String version);

    /**
     * Служит для предоставления конкретного поля тест-кейса {@link TestCase}
     *
     * @param testCaseID   идентификатор тест-кейса из Jira (example: "VPEPVV-T803", "ASPPODDELTA-T1082")
     * @param valueTypeRef класс представления поля тест-кейса
     * @param fields       имя поля тест кейса
     * @return представление конкретного поля тест-кейса
     */
    <T> T getFieldsByTestCase(String testCaseID, TypeReference<T> valueTypeRef, String... fields);

    /**
     * Служит для получения приоритета тест-кейса
     *
     * @param testCaseID идентификатор тест-кейса из Jira (example: "VPEPVV-T803", "ASPPODDELTA-T1082")
     * @param version    версия тест-кейса из Jira (example: "1")
     * @return уровень приоритета в виде строки (example: "HIGH", "LOW", "NORMAL")
     */
    String getPriorityByTestCase(String testCaseID, String version);

    /**
     * Служит для получения параметров тест-кейса
     *
     * @param testCaseID идентификатор тест-кейса из Jira (example: "SADDTU-T2345","SADDTU-T2350")
     * @return параметры тест-кейса
     */
    Parameters getParametersByTestCase(String testCaseID);

    /**
     * Служеь для получения параметров тест-кейса с учетом версии
     *
     * @param testCaseID идентификатор тест-кейса из Jira (example: "SADDTU-T2345","SADDTU-T2350")
     * @param version    версия тест-кейса из Jira (example: "1")
     * @return параметры тест-кейса
     */
    Parameters getParametersByTestCase(String testCaseID, String version);

    /**
     * Служит для предоставления тестовых данных указанных в тест-кейсе {@link TestData}
     *
     * @param testCaseID идентификатор тест-кейса из Jira (example: "VPEPVV-T803", "ASPPODDELTA-T1082")
     */
    Stream<TestData> getTestData(String testCaseID);

    /**
     * Служит для предоставления тестовых данных указанных в тест-кейсе {@link TestData}
     *
     * @param testCaseID идентификатор тест-кейса из Jira (example: "VPEPVV-T803", "ASPPODDELTA-T1082")
     * @param version    версия тест-кейса из Jira (example: "1")
     */
    Stream<TestData> getTestData(String testCaseID, String version);

    /**
     * Служит для предоставления шагов указанных в тест-кейсе {@link Step}
     *
     * @param testCaseID идентификатор тест-кейса из Jira (example: "VPEPVV-T803", "ASPPODDELTA-T1082")
     */
    List<Step> getTestSteps(String testCaseID);

    /**
     * Служит для предоставления шагов указанных в тест-кейсе {@link Step}
     *
     * @param testCaseID идентификатор тест-кейса из Jira (example: "VPEPVV-T803", "ASPPODDELTA-T1082")
     * @param version    версия тест-кейса из Jira (example: "1")
     */
    List<Step> getTestSteps(String testCaseID, String version);

    /**
     * Служит для предоставления вложений указанных в тест-кейсе.
     *
     * @param testCaseId        идентификатор тест-кейса из Jira (example: "VPEPVV-T803", "ASPPODDELTA-T1082")
     * @param downloadDirectory полный путь для сохранения вложений содержащихся в тест-кейсе
     *                          (example: "(user.dir)/build/resources/test/testData/T803")
     */
    List<File> downloadAttachments(String testCaseId, Path downloadDirectory);

    /**
     * Служит для предоставления вложений указанных в тест-кейсе определенной версии.
     *
     * @param testCaseId        идентификатор тест-кейса из Jira (example: "VPEPVV-T803", "ASPPODDELTA-T1082")
     * @param version           версия тест-кейса из Jira (example: "1")
     * @param downloadDirectory полный путь для сохранения вложений содержащихся в тест-кейсе
     *                          (example: "(user.dir)/build/resources/test/testData/T803")
     */
    List<File> downloadAttachments(String testCaseId, String version, Path downloadDirectory);

    /**
     * Служит для предоставления вложений указанных в тест-кейсе с определенными именами
     *
     * @param testCaseId        идентификатор тест-кейса из Jira (example: "VPEPVV-T803", "ASPPODDELTA-T1082")
     * @param downloadDirectory полный путь для сохранения вложений содержащихся в тест-кейсе (example: "(user.dir)/build/resources/test/testData/T803")
     * @param filenames         имена необходимых для загрузки файлов
     */
    List<File> downloadAttachments(String testCaseId, Path downloadDirectory, String... filenames);

    /**
     * Служит для предоставления вложений указанных в тест-кейсе определенной версии и с определенными именами
     *
     * @param testCaseId        идентификатор тест-кейса из Jira (example: "VPEPVV-T803", "ASPPODDELTA-T1082")
     * @param version           версия тест-кейса (example: "3")
     * @param downloadDirectory полный путь для сохранения вложений содержащихся в тест-кейсе (example: "(user.dir)/build/resources/test/testData/T803")
     * @param filenames         имена необходимых для загрузки файлов
     */
    List<File> downloadAttachments(String testCaseId, String version, Path downloadDirectory, String... filenames);


    /**
     * Служит для предоставления всех версий тест-кейса по идентификатору
     *
     * @param testCaseId        идентификатор тест-кейса из Jira (examples: "VPEPVV-T803", "ASPPODDELTA-T1082")
     * @return список версий тест-кейса
     */
    List<VersionDTO> getAllVersionsTestCaseById(String testCaseId);


    /**
     * Позволяет получить целочисленный идентификатор, указанной версии тест-кейса, по его универсальному идентификатору
     *
     * @param testCaseId   "универсальный" идентификатор тест-кейса (example: "VPEPVV-T803", "ASPPODDELTA-T1082")
     * @param majorVersion версия тест-кейса (example: "1", "4")
     * @return целочисленный идентификатор тест-кейса (example: "136753", "116979")
     */
    String getTestCaseIdByMajorVersion(String testCaseId, String majorVersion);
}
