package jira.api.testRunAPI;

import dto.testRun.TestRunDTO;
import dto.testRun.TestRunItemDTO;
import jira.api.impl.JiraTestRunImpl;
import jiraClient.JiraClientSingleton;

import java.util.List;

public interface JiraTestRunAPI {

    static JiraTestRunAPI getDefault() {
        return new JiraTestRunImpl(JiraClientSingleton.getJiraClient());
    }

    /**
     * Получает список элементов тестового прогона (test run items) по идентификатору тестового прогона.
     *
     * <p>Каждый элемент содержит информацию о тест-кейсе, его версии, статусе выполнения и других атрибутах,
     * необходимых для отображения и обработки результатов прогона.</p>
     *
     * @param testRunId идентификатор тестового прогона в Jira (например: "67075", "12345")
     * @return список элементов тестового прогона, представленных в виде {@link TestRunItemDTO}
     * @throws IllegalArgumentException если {@code testRunId} равен {@code null} или пустой строке
     */
    List<TestRunItemDTO> getTestRunItems(String testRunId);

    /**
     * Получает информацию о тестовом прогоне по его идентификатору.
     *
     * @param testRunId идентификатор тестового прогона в Jira (например: "PERUFR-C4")
     * @return данные тестового прогона в виде {@link TestRunDTO}
     */
    TestRunDTO getTestRunInfo(String testRunId);
}
