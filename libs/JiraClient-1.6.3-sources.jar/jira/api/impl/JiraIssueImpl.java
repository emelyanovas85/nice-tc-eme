package jira.api.impl;

import bugbusters.modules.restclients.httpclient.HttpClient;
import bugbusters.modules.restclients.httpclient.HttpRequest;
import bugbusters.modules.restclients.httpclient.RequestBody;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import dto.issue.Issue;
import jira.api.issueAPI.JiraIssueAPI;
import jiraClient.JiraClient;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class JiraIssueImpl implements JiraIssueAPI {
    private final HttpClient httpClient;
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    public JiraIssueImpl(JiraClient jiraClient) {
        this.httpClient = jiraClient.getHttpClient();
    }

    @Override
    public List<Issue> findIssues(Filer filer) {
        HttpRequest request = httpClient.GET("/rest/api/2/search");
        request.addHeader("X-Atlassian-Token", "no-check");
        request.addQueryParameter("jql", "labels=" + filer.getValue());
        request.addQueryParameter("fields", "key");
        try (Response response = request.execute()) {
            if (!response.isSuccessful()) {
                logger.error("Задача не найдена в указанному фильтру: " + filer.getValue() + "!\n" +
                        "Код ошибки запроса: " + response.code() + "\n" +
                        "Сообщение: " + response.message());
                return Collections.emptyList();
            }
            Map<String, Object> map = objectMapper.readValue(Objects.requireNonNull(response.body()).string(), new TypeReference<Map<String, Object>>() {
            });
            String issues = objectMapper.writeValueAsString(map.get("issues"));
            List<Issue> issueList = objectMapper.readValue(issues, new TypeReference<List<Issue>>() {
            });
            if (issueList == null)
                return Collections.emptyList();
            return issueList;
        } catch (IOException ex) {
            logger.error("Не удалось выполнить запрос на поиск задачи по указанному фильтру " + filer.getValue(), ex);
        }
        return Collections.emptyList();
    }

    @Override
    public Optional<Issue> findIssue(Filer filer) {
        return findIssues(filer).stream().findFirst();
    }

    @Override
    public void uploadFiles(String issueId, File... files) {
        try {
            RequestBody requestBody = httpClient.getRequestBody(files);
            uploadContent(issueId, requestBody);
        } catch (IOException ex) {
            logger.error("Не удалось выполнить запрос на прикрепление файлов к задаче '" + issueId + "'!");
        }
    }

    @Override
    public void uploadJson(String issueId, String name, String json) {
        okhttp3.RequestBody jsonRequestBody = okhttp3.RequestBody.create(
                json, MediaType.parse("application/json"));

        MultipartBody.Builder builder = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("file", name, jsonRequestBody);

        RequestBody requestBody = new RequestBody();
        requestBody.setRequestBody(builder.build());
        uploadContent(issueId, requestBody);
    }

    private void uploadContent(String issueId, RequestBody requestBody) {
        Response response = null;
        try {
            HttpRequest request = httpClient.POST("rest/api/2/issue/" + issueId + "/attachments", requestBody);
            request.addHeader("X-Atlassian-Token", "no-check");
            response = request.execute();
            if (!response.isSuccessful())
                logger.error("Не удалось выполнить запрос на прикрепление файла к задаче \n" +
                        "Код ошибки запроса: " + response.code() + "\n" +
                        "Сообщение: " + response.message());
        } catch (IOException ex) {
            logger.error("Не удалось выполнить запрос на прикрепление файлов к задаче '" + issueId + "'!");
        } finally {
            if (response != null)
                response.close();
        }
    }
}