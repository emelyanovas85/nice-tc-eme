package jira.api.impl;

import bugbusters.modules.restclients.httpclient.HttpClient;
import bugbusters.modules.restclients.httpclient.HttpRequest;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.errorprone.annotations.CheckReturnValue;
import dto.testCase.*;
import impl.Parameters;
import impl.Step;
import impl.TestCase;
import impl.TestData;
import jira.api.testCaseAPI.JiraTestCaseAPI;
import jiraClient.JiraClient;
import mappers.StepMapper;
import mappers.TestCaseMapper;
import mappers.TestDataMapper;
import okhttp3.Response;
import okhttp3.ResponseBody;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static java.util.Arrays.asList;
import static java.util.Comparator.comparingInt;
import static java.util.stream.Collectors.*;

public class JiraTestCaseImpl implements JiraTestCaseAPI {
    private final HttpClient httpClient;
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    public JiraTestCaseImpl(JiraClient jiraClient) {
        this.httpClient = jiraClient.getHttpClient();
    }

    @Override
    public String requestToJira(String testCaseID, String... fields) {
        HttpRequest request = httpClient.GET("/rest/tests/1.0/testcase/" + testCaseID);
        if (fields.length > 0) {
            request.addQueryParameter("fields", String.join(",", fields)); // повторное присваивание не срабатывает, приходится вручную джойнить через запятую
        }
        try (Response response = request.execute()) {
            ResponseBody body = response.body();
            return (body != null) ? body.string() : "";
        } catch (Exception ex) {
            throw new RuntimeException(ex.getMessage());
        }
    }

    @Override
    public TestCase getTestCase(String testCaseID) {
        String jsn = requestToJira(testCaseID);
        try {
            TestCaseDTO testCaseDTO = objectMapper.readValue(jsn, TestCaseDTO.class);
            return TestCaseMapper.fromDTO(testCaseDTO);
        } catch (IOException ex) {
            throw new RuntimeException(ex.getMessage());
        }
    }

    @Override
    public TestCase getTestCase(String testCaseID, String version) {
        String testCaseIdByMajorVersion = getTestCaseIdByMajorVersion(testCaseID, version);
        return getTestCase(testCaseIdByMajorVersion);
    }

    @Override
    public <T> T getFieldsByTestCase(String testCaseID, TypeReference<T> valueTypeRef, String... fields) {
        HttpRequest request = httpClient.GET("/rest/tests/1.0/testcase/" + testCaseID);
        if (fields.length > 0) {
            request.addQueryParameter("fields", String.join(",", fields)); // повторное присваивание не срабатывает, приходится вручную джойнить через запятую
        }
        try (Response response = request.execute()) {
            return objectMapper.readValue(Objects.requireNonNull(response.body()).string(), valueTypeRef);
        } catch (Exception ex) {
            throw new RuntimeException(ex.getMessage());
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    public String getPriorityByTestCase(String testCaseID, String version) {
        String testCaseIdByMajorVersion = getTestCaseIdByMajorVersion(testCaseID, version);
        String jsn = requestToJira(testCaseIdByMajorVersion, "priority");
        try {
            Map<String, Object> map = objectMapper.readValue(jsn, new TypeReference<Map<String, Object>>() {
            });
            Map<String, Object> priority = (Map<String, Object>) map.get("priority");
            return ((String) priority.get("name"));
        } catch (IOException ex) {
            throw new RuntimeException(ex.getMessage());
        }
    }

    @Override
    public Parameters getParametersByTestCase(String testCaseID) {
        String jsn = requestToJira(testCaseID, "parameters");
        try {
            List<TestParameterDTO> parameterDTOS = objectMapper.readValue(jsn, new TypeReference<List<TestParameterDTO>>() {
            });
            Map<String, String> parameters = new HashMap<>(parameterDTOS.size());
            parameterDTOS.forEach(par -> parameters.put(par.name, par.defaultValue));
            return new Parameters(parameters);
        } catch (IOException ex) {
            throw new RuntimeException(ex.getMessage());
        }
    }

    @Override
    public Parameters getParametersByTestCase(String testCaseID, String version) {
        String testCaseIdByMajorVersion = getTestCaseIdByMajorVersion(testCaseID, version);
        return getParametersByTestCase(testCaseIdByMajorVersion);
    }

    @Override
    public Stream<TestData> getTestData(String testCaseID) {
        String json;

        try (Response response = httpClient.GET("/rest/tests/1.0/testcase/" + testCaseID)
                .addQueryParameter("fields", "testData").execute()) {
            ResponseBody body = response.body();
            json = body != null ? body.string() : "";
            TypeReference<Map<String, TestDataDTO>> ref = new TypeReference<Map<String, TestDataDTO>>() {
            };
            Map<String, TestDataDTO> testData = objectMapper.readValue(json, ref);
            return TestDataMapper.fromDTO(testData.get("testData")).stream();
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage());
        }
    }

    @Override
    public Stream<TestData> getTestData(String testCaseID, String version) {
        String testCaseIdByMajorVersion = getTestCaseIdByMajorVersion(testCaseID, version);
        return getTestData(testCaseIdByMajorVersion);
    }

    @Override
    public List<Step> getTestSteps(String testCaseID) {
        try {
            String testScript = requestToJira(testCaseID, "testScript");
            TypeReference<Map<String, TestScriptDTO>> ref = new TypeReference<Map<String, TestScriptDTO>>() {
            };
            List<StepDTO> steps = objectMapper.readValue(testScript, ref).get("testScript").stepByStepScriptDTO.steps;
            return steps.stream()
                    .map(StepMapper::fromDTO)
                    .sorted(comparingInt(Step::getStepNumber))
                    .collect(toList());
        } catch (IOException ex) {
            throw new RuntimeException(ex.getMessage());
        }
    }

    @Override
    public List<Step> getTestSteps(String testCaseID, String version) {
        String testCaseIdByMajorVersion = getTestCaseIdByMajorVersion(testCaseID, version);
        return getTestSteps(testCaseIdByMajorVersion);
    }

    @Override
    public List<File> downloadAttachments(String testCaseId, Path downloadDirectory) {
        List<AttachmentDTO> attachments = getAttachments(testCaseId);
        return downloadAttachments0(attachments, downloadDirectory);
    }

    @Override
    public List<File> downloadAttachments(String testCaseId, Path downloadDirectory, String... filenames) {
        if (filenames.length == 0)
            throw new IllegalArgumentException("Не указано ни одного названия файла из вложений!");
        Set<String> filenamesSet = new HashSet<>(asList(filenames));

        List<AttachmentDTO> attachments = getAttachments(testCaseId);
        List<AttachmentDTO> requestedAttachments = attachments.stream()
                .filter(it -> filenamesSet.remove(it.getFileName()))
                .collect(toCollection(ArrayList::new));

        if (!filenamesSet.isEmpty())
            throw new RuntimeException("Во вложениях не были найдены файлы: " + filenamesSet + ".\n Список вложений: " + attachments);

        return downloadAttachments0(requestedAttachments, downloadDirectory);
    }

    /**
     * Синхронно скачивает файлы с одинаковыми именами и проверяет их на полное совпадение
     */
    private void downloadAndCheckFilesWithEqualName(Path downloadDirectory, Map<String, List<AttachmentDTO>> attachmentsWithEqualName) {
        final ArrayList<String> duplicateFileNames = new ArrayList<>();
        for (Map.Entry<String, List<AttachmentDTO>> entry : attachmentsWithEqualName.entrySet()) {
            final List<AttachmentDTO> value = entry.getValue();
            final List<String> uuids = new ArrayList<>(value.size());
            for (AttachmentDTO attachmentDTO : value) {
                final String uuid = UUID.randomUUID().toString();
                uuids.add(uuid);
                try (Response response = httpClient.GET("/rest/tests/1.0/attachment/" + attachmentDTO.getId()).download(downloadDirectory.resolve(uuid))) {
                    if (response.code() != 200) {
                        throw new RuntimeException("Не удалось загрузить файл: " + entry.getKey());
                    }
                } catch (IOException e) {
                    throw new UncheckedIOException("Произошла ошибка IO", e);
                }
            }

            final boolean passed = testFilesForEquality(uuids.stream().map(downloadDirectory::resolve).collect(toList()));
            if (!passed) {
                duplicateFileNames.add(entry.getKey());
            }
            try {
                Files.move(downloadDirectory.resolve(uuids.get(0)), downloadDirectory.resolve(entry.getKey()));
                for (String name : uuids.subList(1, uuids.size())) {
                    Files.delete(downloadDirectory.resolve(name));
                }
            } catch (IOException e) {
                throw new UncheckedIOException("Возникла ошибка IO", e);
            }
        }

        if (!duplicateFileNames.isEmpty()) {
            throw new IllegalStateException("В ТК присутствуют файлы" + duplicateFileNames +
                    "с одинаковыми именами, но разным содержимым");
        }
    }

    @CheckReturnValue
    private boolean testFilesForEquality(List<Path> collect) {
        if (collect.stream().anyMatch(Files::notExists))
            throw new IllegalStateException("Ошибка при проверке файлов на точное соответствие: один из файлов не существует");

        if (collect.size() < 2) return true;

        try {
            final byte[] reference = Files.readAllBytes(collect.get(0));

            for (int i = 1; i < collect.size(); i++) {
                if (!Arrays.equals(reference, Files.readAllBytes(collect.get(i))))
                    return false;
            }
        } catch (IOException e) {
            throw new UncheckedIOException("Ошибка IO при чтении содержимого файла", e);
        }

        return true;
    }

    @Override
    public List<File> downloadAttachments(String testCaseId, String version, Path downloadDirectory, String... filenames) {
        String testCaseIdByMajorVersion = getTestCaseIdByMajorVersion(testCaseId, version);
        return downloadAttachments(testCaseIdByMajorVersion, downloadDirectory, filenames);
    }

    @Override
    public List<File> downloadAttachments(String testCaseId, String version, Path downloadDirectory) {
        String testCaseIdByMajorVersion = getTestCaseIdByMajorVersion(testCaseId, version);
        return downloadAttachments(testCaseIdByMajorVersion, downloadDirectory);
    }

    private List<File> downloadAttachments0(List<AttachmentDTO> attachments, Path downloadDirectory) {
        final Map<String, List<AttachmentDTO>> attachmentsWithEqualName = attachments.stream()
                .collect(groupingBy(AttachmentDTO::getFileName))
                .entrySet().stream()
                .filter(e -> e.getValue().size() > 1)
                .collect(toMap(Map.Entry::getKey, Map.Entry::getValue));

        if (!attachmentsWithEqualName.isEmpty()) {
            downloadAndCheckFilesWithEqualName(downloadDirectory, attachmentsWithEqualName);
            attachments.removeIf(att -> attachmentsWithEqualName.containsKey(att.getFileName()));
        }

        List<CompletableFuture<File>> futures = attachments.stream()
                .map(attachment -> {
                    int attachmentId = attachment.getId();
                    String attachmentName = attachment.getFileName();

                    return CompletableFuture.supplyAsync(() -> {
                        try (Response response = httpClient.GET("/rest/tests/1.0/attachment/" + attachmentId)
                                .download(downloadDirectory.resolve(attachmentName))) {
                            if (response.code() != 200) {
                                throw new RuntimeException("Не удалось загрузить файл: " + attachmentName);
                            }
                            return downloadDirectory.resolve(attachmentName).toFile();
                        } catch (IOException e) {
                            logger.warn("Произошла ошибка ввода-вывода: " + e.getMessage());
                            throw new CompletionException(e);
                        }
                    });
                })
                .collect(Collectors.toList());

        return futures.stream()
                .map(CompletableFuture::join)
                .collect(Collectors.toList());
    }

    @Override
    public List<VersionDTO> getAllVersionsTestCaseById(String testCaseId) {
        HttpRequest request = httpClient.GET("/rest/tests/1.0/testcase/" + testCaseId + "/allVersions");
        request.addQueryParameter("fields", "id,majorVersion");
        try (Response response = request.execute()) {
            if (!response.isSuccessful())
                throw new RuntimeException("Ошибка запроса: " + response.code() + " " + response.message());

            ResponseBody body = response.body();
            if (body == null) throw new RuntimeException("Вернулся пустое тело запроса!!");


            return objectMapper.readValue(body.string(), new TypeReference<List<VersionDTO>>() {
            });
        } catch (IOException ex) {
            throw new RuntimeException("Ошибка обработки ответа: " + ex.getMessage(), ex);
        } catch (Exception ex) {
            throw new RuntimeException("Неизвестная ошибка: " + ex.getMessage(), ex);
        }
    }

    @Override
    public String getTestCaseIdByMajorVersion(String testCaseId, String majorVersion) {
        List<VersionDTO> allVersionsTestCaseById = getAllVersionsTestCaseById(testCaseId);
        int id = allVersionsTestCaseById
                .stream()
                .filter(it -> String.valueOf(it.getMajorVersion()).equals(majorVersion))
                .findFirst()
                .orElseThrow(() -> new RuntimeException("Тест-кейс данной версии '" + majorVersion + "' не найден"))
                .getId();
        return String.valueOf(id);
    }


    private List<AttachmentDTO> getAttachments(String testCaseID) {
        final String responseJson;
        try (Response response =
                     httpClient.GET("/rest/tests/1.0/testcase/" + testCaseID)
                             .addQueryParameter("fields", "attachments,testScript(steps(id,index,attachments))")
                             .execute()) {
            ResponseBody body = response.body();
            if (body == null) {
                return Collections.emptyList();
            }

            responseJson = body.string();


            ArrayList<AttachmentDTO> allAttachments = new ArrayList<>();
            Map<String, Object> testScriptAndAttachments = objectMapper.readValue(responseJson, new TypeReference<Map<String, Object>>() {
            });
            if (testScriptAndAttachments.containsKey("attachments")) {
                String attachmentsJson = objectMapper.writeValueAsString(testScriptAndAttachments.get("attachments"));
                List<AttachmentDTO> testCaseAttachments = objectMapper.readValue(attachmentsJson, new TypeReference<List<AttachmentDTO>>() {
                });
                allAttachments.addAll(testCaseAttachments);
            }
            if (testScriptAndAttachments.containsKey("testScript")) {
                String testScriptJson = objectMapper.writeValueAsString(testScriptAndAttachments.get("testScript"));
                TestScriptDTO testScriptDTO = objectMapper.readValue(testScriptJson, new TypeReference<TestScriptDTO>() {
                });
                List<AttachmentDTO> stepAttachments = testScriptDTO.stepByStepScriptDTO.steps.stream()
                        .map(stepDTO -> stepDTO.attachmentDTOs)
                        .filter(att -> !att.isEmpty())
                        .flatMap(Collection::stream)
                        .collect(toList());
                allAttachments.addAll(stepAttachments);
            }
            return allAttachments;
        } catch (IOException ex) {
            throw new RuntimeException(ex.getMessage());
        }
    }
}
