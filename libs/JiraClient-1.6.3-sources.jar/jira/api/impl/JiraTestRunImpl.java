package jira.api.impl;

import bugbusters.modules.restclients.httpclient.HttpClient;
import bugbusters.modules.restclients.httpclient.HttpRequest;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import dto.testRun.TestRunDTO;
import dto.testRun.TestRunItemDTO;
import jira.api.testRunAPI.JiraTestRunAPI;
import jiraClient.JiraClient;
import okhttp3.Response;
import okhttp3.ResponseBody;

import java.io.IOException;
import java.util.List;

public class JiraTestRunImpl implements JiraTestRunAPI {

    private final HttpClient httpClient;
    private final ObjectMapper objectMapper = new ObjectMapper();

    public JiraTestRunImpl(JiraClient jiraClient) {
        this.httpClient = jiraClient.getHttpClient();
    }

    @Override
    public List<TestRunItemDTO> getTestRunItems(String testRunId) {
        HttpRequest request = httpClient.GET("/rest/tests/1.0/testrun/" + testRunId + "/testrunitems");
        request.addQueryParameter("fields", "id,index,$lastTestResult");
        try (Response response = request.execute()) {
            if (!response.isSuccessful())
                throw new RuntimeException("Ошибка ответа: " + response.code() + " " + response.message());

            ResponseBody body = response.body();
            if (body == null) throw new RuntimeException("Вернулось пустое тело ответа!!");

            return objectMapper.readValue(body.string(), new TypeReference<List<TestRunItemDTO>>() {
            });
        } catch (IOException ex) {
            throw new RuntimeException("Ошибка обработки ответа: " + ex.getMessage(), ex);
        } catch (Exception ex) {
            throw new RuntimeException("Неизвестная ошибка: " + ex.getMessage(), ex);
        }
    }

    @Override
    public TestRunDTO getTestRunInfo(String testRunId) {
        HttpRequest request = httpClient.GET("/rest/tests/1.0/testrun/" + testRunId);
        request.addQueryParameter("fields", "id,key,name,projectId,projectVersionId,environmentId,plannedStartDate,plannedEndDate,iteration(name),executionTime,estimatedTime");
        try (Response response = request.execute()) {
            if (!response.isSuccessful())
                throw new RuntimeException("Ошибка запроса: " + response.code() + " " + response.message());

            ResponseBody body = response.body();
            if (body == null) throw new RuntimeException("Вернулся пустое тело запроса!!");

            return objectMapper.readValue(body.string(), new TypeReference<TestRunDTO>() {});
        } catch (IOException ex) {
            throw new RuntimeException("Ошибка обработки ответа: " + ex.getMessage(), ex);
        } catch (Exception ex) {
            throw new RuntimeException("Неизвестная ошибка: " + ex.getMessage(), ex);
        }
    }
}
