package jira.api.issueAPI;

import dto.issue.Issue;
import jiraClient.JiraClientSingleton;
import jira.api.impl.JiraIssueImpl;

import java.io.File;
import java.util.List;
import java.util.Optional;

public interface JiraIssueAPI {

    static JiraIssueAPI getDefault() {
        return new JiraIssueImpl(JiraClientSingleton.getJiraClient());
    }

    /**
     * Служит для поиска задач в jira
     * Если ни одной задачи не найдено вернется пустой список
     * @param filer значение фильтра,
     *              по которому выполняется поиск задач с указанной в фильтре меткой {@link Filer}
     * @return список найденных задач с меткой
     */
    List<Issue> findIssues(Filer filer);

    /**
     * Служит для поиска задачи в jira по фильтру
     *
     * @param filer значение фильтра,
     *              по которому выполняется поиск задач с указанной в фильтре меткой {@link Filer}
     * @return первую найденную задачу по фильтру
     */
    Optional<Issue> findIssue(Filer filer);

    /**
     * Служит для прикрепления файлов к задаче
     *
     * @param issueId идентификатор задачи
     * @param files   файлы, которые необходимо прикрепить
     */
    void uploadFiles(String issueId, File... files);

    /**
     * Служит для прикрепления json к задаче
     * @param issueId идентификатор задачи
     * @param name    имя json для прикрепления к задаче
     * @param json    json в виде строки
     */
    void uploadJson(String issueId, String name, String json);


    /**
     * Используется в jql запросе для поиска задачи по метке
     */
    interface Filer {
        /**
         * Под value понимается метка, которой помечается задача в jira.
         * При необходимости оборачивать в одинарные кавычки
         */
        String getValue();
    }

    enum FilerJsoner implements Filer {
        AT_for_VBI("'AT_for_VBI'"),
        AT_for_POL("'AT_for_POL'");

        final String value;

        FilerJsoner(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }
    }
}

