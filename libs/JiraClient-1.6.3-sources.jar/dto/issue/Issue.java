package dto.issue;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Issue {
    private final String id;
    private final String key;
    private final String self;

    @JsonCreator
    public Issue(@JsonProperty("id") String id,
                 @JsonProperty("key") String key,
                 @JsonProperty("self") String self) {
        this.id = id;
        this.key = key;
        this.self = self;
    }

    public String getId() {
        return id;
    }
}
