package dto.testCase;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.LinkedHashMap;
import java.util.Map;

@JsonIgnoreProperties("id")
public class TestDataRowDTO extends LinkedHashMap<String, Map<String, String>>{
}
