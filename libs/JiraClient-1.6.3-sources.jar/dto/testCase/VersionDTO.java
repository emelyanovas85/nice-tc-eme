package dto.testCase;

public  class VersionDTO {
    private int id;
    private int majorVersion;

    public VersionDTO() {}

    public VersionDTO(int id, int majorVersion) {
        this.id = id;
        this.majorVersion = majorVersion;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getMajorVersion() {
        return majorVersion;
    }

    public void setMajorVersion(int majorVersion) {
        this.majorVersion = majorVersion;
    }
}
