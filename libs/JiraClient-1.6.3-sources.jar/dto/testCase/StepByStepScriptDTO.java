package dto.testCase;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

import static java.util.Collections.emptyList;
import static java.util.Collections.unmodifiableList;

@JsonIgnoreProperties("id")
public class StepByStepScriptDTO {
    public List<StepDTO> steps;

    @JsonCreator
    public StepByStepScriptDTO(@JsonProperty("steps") List<StepDTO> steps) {
        this.steps = steps != null ? unmodifiableList(steps) : emptyList();
    }
}
