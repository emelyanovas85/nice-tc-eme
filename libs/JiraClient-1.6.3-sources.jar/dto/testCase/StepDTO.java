package dto.testCase;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

import static java.util.Collections.emptyList;
import static java.util.Collections.unmodifiableList;

@JsonIgnoreProperties({"customFieldValues", "stepParameters"})
public class StepDTO {
    public final int id;
    public final int index;
    public final String testData;
    public final String description;
    public final String expectedResult;
    public final InnerTestCaseDTO testCaseDTO;
    public List<AttachmentDTO> attachmentDTOs;

    @JsonCreator
    public StepDTO(
            @JsonProperty("testData") String testData,
            @JsonProperty("expectedResult") String expectedResult,
            @JsonProperty(value = "index", required = true) int index,
            @JsonProperty("description") String description,
            @JsonProperty(value = "id", required = true) int id,
            @JsonProperty("testCase") InnerTestCaseDTO testCaseDTO,
            @JsonProperty("attachments") List<AttachmentDTO> attachmentDTOs) {
        this.testData = testData;
        this.expectedResult = expectedResult;
        this.index = index;
        this.description = description;
        this.id = id;
        this.testCaseDTO = testCaseDTO;
        this.attachmentDTOs = attachmentDTOs != null ? unmodifiableList(attachmentDTOs) : emptyList();
    }
}
