package dto.testCase;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import java.util.Map;

@JsonIgnoreProperties({
        "owner", "testResults", "updatedBy", "precondition", "updatedOn",
        "createdOn", "objective", "paramType", "archived", "folder",
        "averageTime", "createdBy", "latestVersion", "testScript",
        "lastTestResultStatus", "id", "projectId", "status", "labels",
        "attachments", "estimatedTime", "customFieldValues", "testData"
})
public class InnerTestCaseDTO {
    public int majorVersion;
    public String testCaseID;
    public String name;
    public List<TestParameterDTO> testParameters;
    public String priority;

    @JsonCreator
    public InnerTestCaseDTO(
            @JsonProperty("majorVersion") int majorVersion,
            @JsonProperty("name") String name,
            @JsonProperty("parameters") List<TestParameterDTO> testParameters,
            @JsonProperty("key") String testCaseID,
            @JsonProperty("priority") Map<String, String> priority) {
        this.testParameters = testParameters;
        this.name = name;
        this.majorVersion = majorVersion;
        this.testCaseID = testCaseID;
        this.priority = priority.get("name");
    }
}
