package dto.testCase;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class TestScriptDTO {
    public StepByStepScriptDTO stepByStepScriptDTO;

    @JsonCreator
    public TestScriptDTO(@JsonProperty("stepByStepScript") StepByStepScriptDTO stepByStepScript) {
        this.stepByStepScriptDTO = stepByStepScript;
    }

//    public List<StepDTO> getStepDTOs() {
//        return stepByStepDTO.getStepDTOs();
//    }
}
