package dto.testCase;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Collections;
import java.util.List;
import java.util.Map;


@JsonIgnoreProperties(ignoreUnknown = true)
public class TestCaseDTO {
    public String id;
    public String precondition;
    public String testCaseID;
    public int majorVersion;
    public String displayName;
    public TestScriptDTO testScriptDTO;
    public List<TestParameterDTO> parameters;
    public TestDataDTO testDataDTO;
    public String priority;

    @JsonCreator
    public TestCaseDTO(
            @JsonProperty("id") String id,
            @JsonProperty("precondition") String precondition,
            @JsonProperty("key") String testCaseID,
            @JsonProperty("majorVersion") int majorVersion,
            @JsonProperty("name") String displayName,
            @JsonProperty("testScript") TestScriptDTO testScriptDTO,
            @JsonProperty("parameters") List<TestParameterDTO> parameters,
            @JsonProperty("testData") TestDataDTO testDataDTO,
            @JsonProperty("priority") Map<String, String> priority) {
        this.id = id;
        this.precondition = precondition;
        this.testCaseID = testCaseID;
        this.majorVersion = majorVersion;
        this.displayName = displayName;
        this.testScriptDTO = testScriptDTO;
        this.parameters = parameters != null ? parameters : Collections.emptyList();
        this.testDataDTO = testDataDTO;
        this.priority = priority != null ? priority.get("name") : null;
    }

    public String getTestCaseID() {
        return testCaseID;
    }

    public int getMajorVersion() {
        return majorVersion;
    }

    public String getDisplayName() {
        return displayName;
    }

    public TestScriptDTO getTestScriptDTO() {
        return testScriptDTO;
    }
}
