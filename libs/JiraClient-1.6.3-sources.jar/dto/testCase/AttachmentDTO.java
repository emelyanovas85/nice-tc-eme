package dto.testCase;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties({"fileName", "fileSize", "createdOn", "userKey", "projectId"})
public class AttachmentDTO {
    private final int id;
    private final String fileName;

    @JsonCreator
    public AttachmentDTO(
            @JsonProperty("id") int id,
            @JsonProperty("name") String fileName) {

        this.id = id;
        this.fileName = fileName;
    }

    public String getFileName() {
        return fileName;
    }

    public int getId() {
        return id;
    }

    @Override
    public String toString() {
        return "'" + fileName + "'";
    }
}
