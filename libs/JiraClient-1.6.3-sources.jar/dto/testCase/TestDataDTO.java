package dto.testCase;

import java.util.ArrayList;

public class TestDataDTO extends ArrayList<TestDataRowDTO> {
}
