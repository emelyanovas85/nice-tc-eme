package dto.testCase;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties("testCase")
public class TestParameterDTO {
    public final String defaultValue;
    public final String name;
    public final int index;
    public final int id;

    @JsonCreator
    public TestParameterDTO(
            @JsonProperty("defaultValue") String defaultValue,
            @JsonProperty("name") String name,
            @JsonProperty("index") int index,
            @JsonProperty("id") int id) {
        this.defaultValue = defaultValue;
        this.name = name;
        this.index = index;
        this.id = id;
    }
}
