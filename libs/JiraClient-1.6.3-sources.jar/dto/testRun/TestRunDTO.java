package dto.testRun;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;


@JsonIgnoreProperties(ignoreUnknown = true)
public class TestRunDTO {

    public long executionTime;
    public long estimatedTime;

    @JsonProperty("plannedStartDate")
    public String plannedStartDate;

    public String name;
    public String id;
    public String projectId;
    public String key;

    @JsonProperty("plannedEndDate")
    public String plannedEndDate;

}