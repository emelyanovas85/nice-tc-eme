package dto.testRun;

import dto.testCase.TestCaseDTO;

public class LastTestResultDTO {
    public long id;
    public String userKey;
    public String assignedTo;
    public long testResultStatusId;
    public TestCaseDTO testCase;
}
