package dto.testRun;

import com.fasterxml.jackson.annotation.JsonProperty;

public class TestRunItemDTO {
    public int index;
    public long id;
    @JsonProperty("$lastTestResult")
    public LastTestResultDTO lastTestResult;

    public int getIndex() {
        return index;
    }

    public LastTestResultDTO getLastTestResult() {
        return lastTestResult;
    }

    public long getId() {
        return id;
    }
}
