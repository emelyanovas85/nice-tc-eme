package jiraClient;

import bugbusters.modules.restclients.httpclient.HttpClient;
import bugbusters.modules.restclients.httpclient.interceptors.CacheInterceptor;
import okhttp3.Cache;
import okhttp3.HttpUrl;

import java.net.CookiePolicy;
import java.util.concurrent.TimeUnit;

import static java.util.Objects.requireNonNull;

public class VbiJiraClient extends JiraClientBase {
    public static JiraClient getDefault() {
        return new VbiBuilder()
                .setDefOrPropsTimeout()
                .setDefOrPropsUrl()
                .build();
    }

    VbiJiraClient(VbiBuilder builder) {
        super(builder);
    }

    @Override
    public String getArtifactoryUrl() {
        return "http://10.128.89.178:8882/";
    }

    @Override
    public String getLogin() {
        return System.getProperty("jira.username", "40svcANFO");
    }

    @Override
    public String getDefaultLogin() {
        return "40svcANFO";
    }

    static class VbiBuilder extends Builder {
        private final HttpClient.Builder httpClientBuilder;

        protected VbiBuilder() {
            httpClientBuilder = new HttpClient.Builder()
                    .cookiePolicy(CookiePolicy.ACCEPT_ALL)
                    .followRedirects(false)
                    .followSslRedirects(false);

            if (CacheInterceptor.isCacheEnabled())
                httpClientBuilder
                        .cache(new Cache(CacheInterceptor.cachePath(), CacheInterceptor.cacheSize()))
                        .addInterceptor(new CacheInterceptor());
        }

        public VbiBuilder setDefOrPropsUrl() {
            String url = System.getProperty("jira.url", "http://s0hjiraas02.vip.cbr.ru:8080");
            httpClientBuilder.url(requireNonNull(HttpUrl.parse(url)));
            return this;
        }

        public VbiBuilder setDefOrPropsTimeout() {
            int connectTimeout = Integer.parseInt(System.getProperty("jira.connectTimeout", "60"));
            int writeTimeout = Integer.parseInt(System.getProperty("jira.writeTimeout", "10"));
            int readTimeout = Integer.parseInt(System.getProperty("jira.readTimeout", "10"));
            httpClientBuilder.connectTimeout(connectTimeout, TimeUnit.SECONDS)
                    .writeTimeout(writeTimeout, TimeUnit.SECONDS)
                    .readTimeout(readTimeout, TimeUnit.SECONDS);
            return this;
        }

        @Override
        public JiraClient build() {
            httpClient = httpClientBuilder.build();
            return new VbiJiraClient(this);
        }
    }
}
