package jiraClient;

import bugbusters.modules.restclients.httpclient.HttpClient;


public interface JiraClient {
    /**
     * Служит для выполнения запросов в определенный сегмент (заранее сконфигурированный и доступный)
     *
     * @return сконфигурированный заранее клиент
     */
    HttpClient getHttpClient();

    /**
     * Метод проверяет доступность Jira с помощью запроса получения тест-кейса
     *
     * @return true - если Jira доступна(код ответа 200), иначе false
     */
    boolean isAvailable();

    /**
     * Метод предоставляет ссылку на artifactory для доступного сегмента
     * @return url artifactory
     */
    String getArtifactoryUrl();

    /**
     * Метод предоставляет логин, с помощью которого получаются данные из Jira
     */
    String getLogin();

    /**
     * Метод предоставляет логин, от технической учетной записи Jira
     */
    String getDefaultLogin();
}
