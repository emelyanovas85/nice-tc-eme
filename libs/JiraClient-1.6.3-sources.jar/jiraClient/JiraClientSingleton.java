package jiraClient;

/**
 * Используется для получения доступной jira из двух сегментов: Poligon и VBI.
 * Внутри конечных реализаций JiraClient определена конфигурация HttpClient,
 * в которой указаны необходимые параметры каждого сегменте.
 */
public class JiraClientSingleton {
    private static final JiraClient jiraClient;

    static {
        JiraClient jiraClientTmp = JiraSnitch.getAvailableJira(PoligonJiraClient.getDefault(), VbiJiraClient.getDefault())
                .orElseThrow(() -> new RuntimeException("Нет доступных jiraClient.JiraClient!"));
        JiraSnitch.setCredentialsForJira(jiraClientTmp);
        jiraClient = jiraClientTmp;
    }

    public static JiraClient getJiraClient() {
        return jiraClient;
    }
}
