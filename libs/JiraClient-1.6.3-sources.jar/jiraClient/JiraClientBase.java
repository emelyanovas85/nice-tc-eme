package jiraClient;

import bugbusters.modules.restclients.httpclient.HttpClient;
import bugbusters.modules.restclients.httpclient.HttpRequest;
import okhttp3.Credentials;
import okhttp3.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public abstract class JiraClientBase implements JiraClient {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    protected HttpClient httpClient;

    protected JiraClientBase(Builder builder) {
        this.httpClient = builder.httpClient;
    }

    @Override
    public HttpClient getHttpClient() {
        return httpClient;
    }

    @Override
    public boolean isAvailable() {
        HttpRequest request = httpClient.GET("");
        try (Response response = request.execute()) {
            return response.code() < 500;
        } catch (Exception ex) {
            logger.warn(ex.getMessage());
            return false;
        }
    }

    public static abstract class Builder {
        protected HttpClient httpClient;

        public Builder setJiraCredentials(String user, String password) {
            httpClient.removeStaticHeader("Authorization");
            httpClient.addStaticHeader("Authorization", Credentials.basic(user, password));
            return this;
        }

        public abstract JiraClient build();
    }
}
