package jiraClient;

import bugbusters.modules.restclients.httpclient.HttpClient;
import bugbusters.modules.restclients.httpclient.interceptors.CacheInterceptor;
import okhttp3.Cache;
import okhttp3.Credentials;
import okhttp3.HttpUrl;

import java.net.CookiePolicy;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

import static java.util.Objects.requireNonNull;

public class PoligonJiraClient extends JiraClientBase {

    public static JiraClient getDefault() {
        return new PoligonBuilder()
                .setDefOrPropsTimeout()
                .setDefOrPropsUrl()
                .build();
    }

    PoligonJiraClient(PoligonBuilder builder) {
        super(builder);
    }

    @Override
    public String getArtifactoryUrl() {
        return "http://10.1.5.6:8882/";
    }

    @Override
    public String getLogin() {
        return System.getProperty("jira.username", "40svc_jira_atst");
    }

    @Override
    public String getDefaultLogin() {
        return "40svc_jira_atst";
    }

    public static class PoligonBuilder extends Builder {
        private final HttpClient.Builder httpClientBuilder;

        public PoligonBuilder() {
            httpClientBuilder = new HttpClient.Builder()
                    .cookiePolicy(CookiePolicy.ACCEPT_ALL)
                    .followRedirects(false)
                    .followSslRedirects(false);

            if (CacheInterceptor.isCacheEnabled())
                httpClientBuilder
                        .cache(new Cache(CacheInterceptor.cachePath(), CacheInterceptor.cacheSize()))
                        .addInterceptor(new CacheInterceptor());
        }

        public PoligonBuilder setDefOrPropsUrl() {
            String url = System.getProperty("jira.url", "http://10.1.1.58");
            httpClientBuilder.url(requireNonNull(HttpUrl.parse(url)));
            return this;
        }

        public PoligonBuilder setDefOrPropsTimeout() {
            int connectTimeout = Integer.parseInt(System.getProperty("jira.connectTimeout", "60"));
            int writeTimeout = Integer.parseInt(System.getProperty("jira.writeTimeout", "10"));
            int readTimeout = Integer.parseInt(System.getProperty("jira.readTimeout", "10"));
            httpClientBuilder.connectTimeout(connectTimeout, TimeUnit.SECONDS)
                    .writeTimeout(writeTimeout, TimeUnit.SECONDS)
                    .readTimeout(readTimeout, TimeUnit.SECONDS);
            return this;
        }

        @Override
        public JiraClient build() {
            super.httpClient = httpClientBuilder.build();
            return new PoligonJiraClient(this);
        }
    }
}
