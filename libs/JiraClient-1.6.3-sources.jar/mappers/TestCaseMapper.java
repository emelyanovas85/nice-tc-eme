package mappers;

import dto.testCase.TestCaseDTO;
import impl.Parameters;
import impl.Step;
import impl.TestCase;
import impl.TestData;

import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static java.util.stream.Collectors.toList;

public class TestCaseMapper {
    /**
     * Преобразует информация о тест кейсе в удобочитаемую форму.
     * Основной задачей является сортировка шагов, вложенных в тест-кейс по индексу.
     * Также, тестовые параметры тест кейса преобразуются из List в Map.
     *
     * @param testCaseDTO сырые данные тест кейса из Jira
     * @return обработанные данные тест кейса
     */
    public static TestCase fromDTO(TestCaseDTO testCaseDTO) {
        String id = testCaseDTO.getTestCaseID();
        int version = testCaseDTO.getMajorVersion();
        String displayName = testCaseDTO.getDisplayName();
        List<Step> steps = testCaseDTO
                .getTestScriptDTO()
                .stepByStepScriptDTO.steps
                .stream()
                .sorted(Comparator.comparingInt(dto -> dto.index))
                .map(StepMapper::fromDTO)
                .collect(toList());
        Map<String, String> parameters = new HashMap<>(testCaseDTO.parameters.size());
        testCaseDTO.parameters.forEach(par -> parameters.put(par.name, par.defaultValue));
        List<TestData> testData = TestDataMapper.fromDTO(testCaseDTO.testDataDTO);

        return new TestCase(id, version, displayName, steps, new Parameters(parameters), testData, testCaseDTO.precondition, testCaseDTO.priority);
    }
}
