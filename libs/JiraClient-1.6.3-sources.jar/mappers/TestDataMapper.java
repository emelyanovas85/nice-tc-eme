package mappers;

import dto.testCase.TestDataDTO;
import dto.testCase.TestDataRowDTO;
import impl.TestData;

import java.util.*;
import java.util.stream.Collectors;

public class TestDataMapper {
    public static List<TestData> fromDTO(TestDataDTO testDataDTO) {
        if (testDataDTO.isEmpty()) return Collections.emptyList();

        List<String> testDataColumnNames = computeColumnNames(testDataDTO);
        return testDataDTO.stream().map(row -> {
            LinkedHashMap<String, String> map = new LinkedHashMap<>();
            testDataColumnNames.forEach(columnName -> {
                final String value = row.containsKey(columnName) ?
                        Optional.ofNullable(row.get(columnName).get("value")).orElse("") :
                        "";
                map.put(columnName, value);
            });
            return new TestData(map);
        }).collect(Collectors.toList());
    }

    private static List<String> computeColumnNames(TestDataDTO testDataDTO) {
        Map<String, Column> name$column = new HashMap<>();
        for (TestDataRowDTO rowDTO : testDataDTO) {
            rowDTO.forEach((columnName, valuesMap) -> {
                final int index = Integer.parseInt(valuesMap.get("index"));
                name$column.computeIfAbsent(columnName, Column::new).addIndex(index);
            });
        }

        final Collection<Column> columns = name$column.values();
        validateColumns(columns);

        return columns.stream()
                .sorted(Comparator.comparingInt(Column::getIndex))
                .map(Column::getName)
                .collect(Collectors.toList());
    }

    private static void validateColumns(Collection<Column> columns) {
        final List<Column> badColumns = columns.stream().filter(Column::isBad).collect(Collectors.toList());
        if (!badColumns.isEmpty()) {
            throw new IllegalStateException("Ошибка при обработке тестовых данных. Присутствуют колонки, имеющие несколько индексов в json:\n" +
                    badColumns.stream()
                            .map(Object::toString)
                            .collect(Collectors.joining("\n"))
            );
        }
    }

    private static class Column {
        final String name;
        final Set<Integer> allIndexes = new HashSet<>();

        private Column(String name) {
            this.name = name;
        }

        public void addIndex(int i) {
            allIndexes.add(i);
        }

        public boolean isBad() {
            return allIndexes.size() != 1;
        }

        @Override
        public String toString() {
            return name + " -> " + allIndexes.stream().sorted().map(String::valueOf).collect(Collectors.joining(", "));
        }

        public String getName() {
            return name;
        }

        public int getIndex() {
            return allIndexes.iterator().next();
        }
    }
}
