package mappers;

import dto.testCase.InnerTestCaseDTO;
import dto.testCase.StepDTO;
import impl.Parameters;
import impl.Step;
import org.apache.commons.text.StringEscapeUtils;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import static java.util.Arrays.stream;
import static java.util.Collections.emptyList;
import static java.util.stream.Collectors.toList;

public class StepMapper {
    /**
     * Преобразует информацию о шаге в удобочитаемую форму.
     * Вложенный в шаг тест-кейс не передается полностью, а сохраняются только
     * имя, версия и ид тест кейса, которые записываются в описание шага.
     * Также, обрабатываются строки описания шага и ожидаемого результата {@link StringEscapeUtils#unescapeHtml4(String)} }
     *
     * @param stepDTO сырые данные шага из Jira
     * @return обработанные данные шага
     */
    public static Step fromDTO(StepDTO stepDTO) {
        int index = stepDTO.index + 1;
        if (stepDTO.testCaseDTO != null) {
            InnerTestCaseDTO testCaseDTO = stepDTO.testCaseDTO;
            String stepDescription = String.format("%s (%d.0) %s", testCaseDTO.testCaseID, testCaseDTO.majorVersion, testCaseDTO.name);
            HashMap<String, String> parameters = new HashMap<>();
            if (testCaseDTO.testParameters != null) {
                testCaseDTO.testParameters.forEach(par -> parameters.put(par.name, par.defaultValue));
            }
            return new Step(index, stepDescription, Collections.singletonList(testCaseDTO.testCaseID + " выполнен"), new Parameters(parameters));
        } else if (stepDTO.description != null) {
            String description = processString(stepDTO.description);

            List<String> expectedResults = emptyList();
            if (stepDTO.expectedResult != null) {
                expectedResults = stream(stepDTO.expectedResult.split("<br>"))
                        .map(StepMapper::processString)
                        .collect(toList());
            }

            return new Step(index, description, expectedResults, new Parameters(Collections.emptyMap()));
        } else {
            throw new RuntimeException("Unable to parse step");
        }
    }

    private static String processString(String str) {
        return StringEscapeUtils.unescapeHtml4(str.replaceAll("<[^<]+>", ""));
    }
}
