package bugbusters.modules.restclients.httpclient;

import bugbusters.modules.restclients.httpclient.exceptions.HttpClientException;
import bugbusters.modules.restclients.httpclient.interceptors.LoggingInterceptor;
import bugbusters.modules.restclients.httpclient.interceptors.StaticHeaderInterceptor;
import okhttp3.*;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.File;
import java.io.IOException;
import java.net.CookiePolicy;
import java.net.HttpCookie;
import java.net.Proxy;
import java.nio.file.FileAlreadyExistsException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

public class HttpClient {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private final OkHttpClient client;
    private HttpUrl url;
    private StaticHeaderInterceptor staticHeaderInterceptor;


    protected HttpClient(OkHttpClient client, HttpUrl url) {
        if (url == null) {
            throw new HttpClientException("HttpClient has been created without URL!");
        }
        this.client = client;
        this.url = url;
    }

    private void setStaticHeaderInterceptor(@NotNull final StaticHeaderInterceptor interceptor) {
        staticHeaderInterceptor = interceptor;
    }

    public void setUrl(String url) {
        setUrl(HttpUrl.get(url));
    }

    public void setUrl(HttpUrl url) {
        this.url = new HttpUrl.Builder()
                .scheme(url.scheme())
                .host(url.host())
                .port(url.port())
                .build();
    }

    OkHttpClient getOkHttpClient() {
        return client;
    }

    public HttpUrl getUrl() {
        return url;
    }

    @NotNull
    public List<HttpCookie> getAllCookies() {
        return ((MyCookieJar) client.cookieJar()).getAllCookies();
    }

    public HttpRequest GET(@NotNull final String path) {
        return new HttpRequest(path, HttpRequest.Method.GET, this);
    }

    public HttpRequest POST(@NotNull final String path, @NotNull final bugbusters.modules.restclients.httpclient.RequestBody body) {
        return new HttpRequest(path, HttpRequest.Method.POST, body, this);
    }

    public HttpRequest PUT(@NotNull final String path, @NotNull final bugbusters.modules.restclients.httpclient.RequestBody body) {
        return new HttpRequest(path, HttpRequest.Method.PUT, body, this);
    }

    public HttpRequest DELETE(@NotNull final String path) {
        return new HttpRequest(path, HttpRequest.Method.DELETE, this);
    }

    public HttpRequest DELETE(@NotNull final String path, @NotNull final bugbusters.modules.restclients.httpclient.RequestBody body) {
        return new HttpRequest(path, HttpRequest.Method.DELETE, body, this);
    }

    public HttpRequest HEAD(@NotNull final String path) {
        return new HttpRequest(path, HttpRequest.Method.HEAD, this);
    }

    public HttpRequest PATCH(@NotNull final String path, @NotNull final RequestBody body) {
        return new HttpRequest(path, HttpRequest.Method.PATCH, body, this);
    }

    public HttpRequest OPTIONS(@NotNull final String path) {
        return new HttpRequest(path, HttpRequest.Method.OPTIONS, this);
    }

    public HttpRequest TRACE(@NotNull final String path) {
        return new HttpRequest(path, HttpRequest.Method.TRACE, this);
    }

    /**
     * Служит для формирования тела запроса с прикрепленными файлами.
     * MediaType - "application/octet-stream"
     *
     * @param files файлы, необходимые для запроса
     * @return Тело запроса с прикрепленными файлами
     */
    public RequestBody getRequestBody(File... files) throws IOException {
        if (!Arrays.stream(files).allMatch(File::exists))
            throw new FileAlreadyExistsException(Arrays.stream(files).map(File::getName).collect(Collectors.joining(",")));
        MultipartBody.Builder builder = new MultipartBody.Builder()
                .setType(MultipartBody.FORM);
        Arrays.stream(files)
                .forEach(it -> builder.addFormDataPart("file", it.getName(),
                        okhttp3.RequestBody.create(it, MediaType.parse("application/octet-stream"))));

        RequestBody requestBody = new RequestBody();
        requestBody.setRequestBody(builder.build());
        return requestBody;
    }


    /**
     * Добавляет статический заголовок (будет во всех запросах, выполняемых этим клиентом).
     * Статический заголовок добавляется, только если в запросе отсутствует заголовок с таким именем.
     */
    public void addStaticHeader(@NotNull final String name, @NotNull final String value) {
        staticHeaderInterceptor.addHeader(name, value);
    }

    /**
     * Удаляет статический заголовок
     */
    public void removeStaticHeader(@NotNull final String name) {
        staticHeaderInterceptor.removeHeader(name);
    }

    /**
     * Выполняет запрос от имени текущего клиента.
     * Рекомендуется использовать, когда один запрос необходимо выполнить несколькими клиентами.
     */
    public Response executeRequest(@NotNull final HttpRequest request) throws IOException {
        return request.execute(this);
    }

    public void addCookie(HttpCookie cookie) {
        Cookie.Builder okHttpCookie = new Cookie.Builder()
                .name(cookie.getName())
                .value(cookie.getValue())
                .expiresAt(cookie.getMaxAge());
        if (cookie.getDomain() != null) okHttpCookie.domain(cookie.getDomain());
        if (cookie.getPath() != null) okHttpCookie.path(cookie.getPath());
        if (cookie.getSecure()) okHttpCookie.secure();
        if (cookie.isHttpOnly()) okHttpCookie.httpOnly();
        client.cookieJar().saveFromResponse(url, Collections.singletonList(okHttpCookie.build()));
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        HttpClient client1 = (HttpClient) o;
        return logger.equals(client1.logger) && client.equals(client1.client) && url.equals(client1.url) && staticHeaderInterceptor.equals(client1.staticHeaderInterceptor);
    }

    @Override
    public int hashCode() {
        return Objects.hash(logger, client, url, staticHeaderInterceptor);
    }

    public static class Builder {
        private final static OkHttpClient singletonClient;

        private final OkHttpClient.Builder okHttpBuilder;
        private HttpUrl url;
        private final MyCookieJar cookieJar;
        private final StaticHeaderInterceptor staticHeaderInterceptor = new StaticHeaderInterceptor();

        static {
            // Создание TrustManager, который доверяет всем сертификатам
            TrustManager[] trustAllCerts = new TrustManager[]{
                    new X509TrustManager() {
                        public X509Certificate[] getAcceptedIssuers() {
                            // Возвращаем пустой массив вместо null
                            return new X509Certificate[0];
                        }

                        public void checkClientTrusted(X509Certificate[] certs, String authType) {
                        }

                        public void checkServerTrusted(X509Certificate[] certs, String authType) {
                        }
                    }
            };
            SSLContext sslContext = null;
            try {

                // Инициализация SSLContext с доверительным менеджером
                sslContext = SSLContext.getInstance("TLS");
                sslContext.init(null, trustAllCerts, new java.security.SecureRandom());

            } catch (NoSuchAlgorithmException | KeyManagementException e) {
                e.printStackTrace();
            }
            singletonClient = new OkHttpClient.Builder()
                    .sslSocketFactory(sslContext.getSocketFactory(), (X509TrustManager) trustAllCerts[0])
                    .build();
        }

        public Builder() {
            cookieJar = new MyCookieJar();
            okHttpBuilder = singletonClient.newBuilder()
                    .addNetworkInterceptor(new LoggingInterceptor())
                    .addInterceptor(staticHeaderInterceptor)
                    .cookieJar(cookieJar);
        }

        /**
         * Привязывает URL к создаваемому клиенту, отбрасывая путь и параметры запроса. <br>
         * Пример: передан URL <a href> https://yandex.ru/qwe/123?id=123&name=unnamed</a>, <br>клиент будет привязан к <a href> https://yandex.ru </a>
         */
        public HttpClient.Builder url(@NotNull final HttpUrl url) {
            this.url = new HttpUrl.Builder()
                    .scheme(url.scheme())
                    .host(url.host())
                    .port(url.port())
                    .build();
            return this;
        }

        public HttpClient.Builder cookiePolicy(@NotNull final CookiePolicy cookiePolicy) {
            cookieJar.setCookiePolicy(cookiePolicy);
            return this;
        }

        public HttpClient.Builder cache(@NotNull final Cache cache) {
            okHttpBuilder.cache(cache);
            return this;
        }

        /**
         * Intrerceptor'ы используются для модификации запроса (например изменяют заголовки при определенных условиях)
         */
        public HttpClient.Builder addInterceptor(@NotNull final Interceptor interceptor) {
            okHttpBuilder.addInterceptor(interceptor);
            return this;
        }

        public final HttpClient.Builder connectTimeout(long timeout, TimeUnit timeUnit) {
            okHttpBuilder.connectTimeout(timeout, timeUnit);

            return this;
        }

        public final HttpClient.Builder writeTimeout(long timeout, TimeUnit timeUnit) {
            okHttpBuilder.writeTimeout(timeout, timeUnit);

            return this;
        }

        public final HttpClient.Builder readTimeout(long timeout, TimeUnit timeUnit) {
            okHttpBuilder.readTimeout(timeout, timeUnit);

            return this;
        }

        public final HttpClient.Builder followRedirects(boolean followRedirects) {
            okHttpBuilder.followRedirects(followRedirects);

            return this;
        }

        public final HttpClient.Builder followSslRedirects(boolean followSslRedirects) {
            okHttpBuilder.followSslRedirects(followSslRedirects);

            return this;
        }

        public final HttpClient.Builder proxy(final Proxy proxy) {
            okHttpBuilder.proxy(proxy);

            return this;
        }

        public final HttpClient build() {
            final HttpClient httpClient = new HttpClient(okHttpBuilder.build(), url);
            httpClient.setStaticHeaderInterceptor(staticHeaderInterceptor);

            return httpClient;
        }
    }

}
