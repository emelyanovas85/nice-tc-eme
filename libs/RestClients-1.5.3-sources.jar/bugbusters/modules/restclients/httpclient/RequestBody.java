package bugbusters.modules.restclients.httpclient;

import okhttp3.MediaType;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

public class RequestBody {
    public enum ContentType {
        APPLICATION_JSON("application/json"), APPLICATION_XML("application/xml"), TEXT_XML("text/xml"), TEXT_HTML("text/html"), TEXT_PLAIN("text/plain");

        private final String contentType;

        ContentType(String contentType) {
            this.contentType = contentType;
        }


        String getValue() {
            return contentType;
        }
    }

    private okhttp3.RequestBody requestBody;

    public RequestBody() {

    }

    private RequestBody(byte[] content, String contentType, String charset) {
        MediaType mediaType = MediaType.get(contentType + ((charset == null) ? "" : ("; charset=" + charset)));
        requestBody = okhttp3.RequestBody.create(content, mediaType);
    }

    okhttp3.RequestBody getRequestBody() {
        return requestBody;
    }

    public void setRequestBody(okhttp3.RequestBody requestBody) {
        this.requestBody = requestBody;
    }

    public static class Builder {
        private byte[] content;
        private String contentType;
        private String charset;

        public Builder() {
        }

        public Builder content(byte[] content) {
            this.content = content;
            return this;
        }

        public Builder content(String content) {
            this.content = content.getBytes(StandardCharsets.UTF_8);
            return this;
        }

        public Builder content(String content, Charset charset) {
            this.charset = charset.displayName();
            this.content = content.getBytes(charset);
            return this;
        }

        public Builder contentType(ContentType contentType) {
            this.contentType = contentType.getValue();
            return this;
        }

        public Builder contentType(String contentType) {
            this.contentType = contentType;
            return this;
        }

        public RequestBody build() {
            return new RequestBody(content, contentType, charset);
        }
    }
}
