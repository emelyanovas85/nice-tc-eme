package bugbusters.modules.restclients.httpclient;

import bugbusters.modules.restclients.httpclient.exceptions.HttpClientException;
import okhttp3.HttpUrl;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import org.jetbrains.annotations.NotNull;

import java.io.*;
import java.nio.channels.Channels;
import java.nio.channels.FileChannel;
import java.nio.channels.ReadableByteChannel;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.Arrays;

public class HttpRequest {
    public enum Method {
        GET, POST, PUT, DELETE, HEAD, PATCH, OPTIONS, TRACE
    }

    private final Request.Builder requestBuilder = new Request.Builder();
    private final String path;
    private HttpClient executor;
    private final HttpUrl.Builder urlBuilder = new HttpUrl.Builder();

    private HttpRequest(@NotNull final String path,
                        @NotNull final Method method) {

        this.path = path;
        requestBuilder.method(method.name(), null);
    }

    private HttpRequest(@NotNull final String path,
                        @NotNull final Method method,
                        @NotNull RequestBody body) {

        this.path = path;
        requestBuilder.method(method.name(), body.getRequestBody());
    }

    public HttpRequest(@NotNull final String path,
                       @NotNull final Method method,
                       @NotNull final HttpClient executor) {

        this(path, method);
        this.executor = executor;
    }

    public HttpRequest(@NotNull final String path,
                       @NotNull final Method method,
                       @NotNull final RequestBody body,
                       @NotNull final HttpClient executor) {

        this(path, method, body);
        this.executor = executor;
    }

    public static HttpRequest GET(@NotNull final String path) {
        return new HttpRequest(path, Method.GET);
    }

    public static HttpRequest POST(@NotNull final String path, @NotNull final RequestBody body) {
        return new HttpRequest(path, Method.POST, body);
    }

    public static HttpRequest PUT(@NotNull final String path, @NotNull final RequestBody body) {
        return new HttpRequest(path, Method.PUT, body);
    }

    public static HttpRequest DELETE(@NotNull final String path) {
        return new HttpRequest(path, Method.DELETE);
    }

    public static HttpRequest DELETE(@NotNull final String path, @NotNull final RequestBody body) {
        return new HttpRequest(path, Method.DELETE, body);
    }

    public static HttpRequest HEAD(@NotNull final String path) {
        return new HttpRequest(path, Method.HEAD);
    }

    public static HttpRequest PATCH(@NotNull final String path, @NotNull final RequestBody body) {
        return new HttpRequest(path, Method.PATCH, body);
    }

    public static HttpRequest OPTIONS(@NotNull final String path) {
        return new HttpRequest(path, Method.OPTIONS);
    }

    public static HttpRequest TRACE(@NotNull final String path) {
        return new HttpRequest(path, Method.TRACE);
    }

    public HttpRequest addHeader(@NotNull final String name, @NotNull final String value) {
        requestBuilder.addHeader(name, value);
        return this;
    }

    public HttpRequest setHeader(@NotNull final String name, @NotNull final String value) {
        requestBuilder.header(name, value);
        return this;
    }

    public HttpRequest removeHeader(@NotNull final String name) {
        requestBuilder.removeHeader(name);
        return this;
    }

    public HttpRequest addQueryParameter(@NotNull final String name, @NotNull final String value) {
        urlBuilder.addQueryParameter(name, value);
        return this;
    }

    public HttpRequest setQueryParameter(@NotNull final String name, @NotNull final String value) {
        urlBuilder.removeAllQueryParameters(name);
        urlBuilder.addQueryParameter(name, value);
        return this;
    }

    public HttpRequest removeAllQueryParametersWithName(@NotNull final String name) {
        urlBuilder.removeAllQueryParameters(name);
        return this;
    }

    public Response execute() throws IOException {
        if (executor == null) throw new HttpClientException("No executor bound to request!");

        return execute(executor);
    }

    private Request getOkHttpRequest(HttpClient executor) {
        final okhttp3.HttpUrl executorUrl = executor.getUrl();
        String[] pathSegments = path.split("/");
        HttpUrl.Builder requestUrl =
                urlBuilder
                        .scheme(executorUrl.scheme())
                        .host(executorUrl.host())
                        .port(executorUrl.port());

        Arrays.stream(pathSegments).forEach(urlBuilder::addPathSegment);

        return requestBuilder.url(requestUrl.build()).build();
    }

    Response execute(@NotNull final HttpClient executor) throws IOException {
        final Request request = getOkHttpRequest(executor);
        return executor.getOkHttpClient().newCall(request).execute();
    }

    public Response download(Path fileName) throws IOException {
        File file = fileName.toFile();
        if (file.exists()) throw new FileAlreadyExistsException(fileName.toString());
        //noinspection ResultOfMethodCallIgnored
        file.getParentFile().mkdirs();
        Response response = this.execute();
        ResponseBody body = response.body();

        if (body != null) {
            try (FileChannel fileChannel = FileChannel.open(fileName, StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE);
                 ReadableByteChannel byteChannel = Channels.newChannel(body.byteStream())) {
                fileChannel.transferFrom(byteChannel, 0, Long.MAX_VALUE);
            }
        }

        return response;
    }
}
