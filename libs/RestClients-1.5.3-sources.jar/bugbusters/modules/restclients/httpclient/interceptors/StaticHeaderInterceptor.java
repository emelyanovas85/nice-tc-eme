package bugbusters.modules.restclients.httpclient.interceptors;

import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;
import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class StaticHeaderInterceptor implements Interceptor {
    private final Map<String, String> staticHeaders = new HashMap<>();

    @NotNull
    @Override
    public Response intercept(@NotNull Chain chain) throws IOException {
        Request originalRequest = chain.request();
        if (staticHeaders.size() == 0) return chain.proceed(originalRequest);

        Request.Builder newRequestBuilder = originalRequest.newBuilder();
        staticHeaders.forEach((name, value) -> {
            if (originalRequest.header(name) == null) {
                newRequestBuilder.addHeader(name, value);
            }
        });

        return chain.proceed(newRequestBuilder.build());
    }

    public void addHeader(String name, String value) {
        staticHeaders.put(name, value);
    }

    public void removeHeader(String name) {
        staticHeaders.remove(name);
    }
}
