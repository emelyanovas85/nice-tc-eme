package bugbusters.modules.restclients.httpclient.interceptors;

import okhttp3.*;
import okio.Buffer;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;

public class LoggingInterceptor implements Interceptor {
    private static final Logger LOG = LoggerFactory.getLogger(LoggingInterceptor.class);

    @NotNull
    @Override
    public Response intercept(Chain chain) throws IOException {
        Request request = chain.request();

        final Instant start = LocalDateTime.now().toInstant(ZoneOffset.UTC);
        Response response = chain.proceed(request);
        final Instant end = LocalDateTime.now().toInstant(ZoneOffset.UTC);
        log(Duration.between(start, end), request, response, null);
        return response;
    }

    private void log(Duration taken, Request request, Response response, Exception e) throws IOException {
        if (LOG.isInfoEnabled() || e != null) {
            final ResponseBody body = response.body();
            final String mediaType;
            if (body != null) {
                final MediaType contentType = body.contentType();
                mediaType = contentType == null ? "" : contentType.type();
            } else {
                mediaType = "";
            }

            String msg = "\n\n\n\nRequest:" +
                    "\n method: " + request.method() +
                    "\n url: " + request.url() +
                    "\nRequest headers:\n " + request.headers() +
                    "\nRequest body:\n  " + bodyToString(request.body()) +
                    "\n-----------------------------------------------------------------------\n" +
                    "\nResponse code: " + response.code() +
                    "\nResponse content-type: " +
                    mediaType +
                    "\nResponse headers:\n" + response.headers() +
                    "\nResponse body:\n " + bodyToString(response) +
                    "\n" +
                    "\n";
            LOG.info(msg, e);
        }
    }

    /**
     * Преобразует тело ответа в строку.
     * Если ответ является файловым (определяется методом isFileResponse),
     * то метод возвращает тело ответа в виде строки, ограниченной размером 1 МБ.
     * В противном случае метод возвращает тело ответа в виде строки без ограничений размера.
     *
     * @param response Ответ, тело которого нужно преобразовать в строку.
     * @return Строковое представление тела ответа.
     * @throws IOException Если возникает ошибка при чтении тела ответа.
     */
    public static String bodyToString(final Response response) throws IOException {
        // Проверяем, является ли ответ файлом
        if (isFileResponse(response)) {
            return ""; //todo: Костыль. Завистает при загрузке файла 100 мб из Jira, надо разбираться
        }
        // Если нет, то возвращаем тело ответа в виде строки без ограничений размера
        return response.peekBody(Long.MAX_VALUE).string();
    }

    /**
     * Определяет, является ли ответ файловым.
     * Файловым считается ответ, у которого есть заголовок "Content-Disposition" со значением "attachment".
     *
     * @param response Ответ, который нужно проверить.
     * @return true, если ответ является файловым, иначе false.
     */
    private static boolean isFileResponse(Response response) {
        // Здесь должна быть логика, определяющая, является ли ответ файлом
        // Например, проверка наличия заголовка "Content-Disposition" со значением "attachment"
        // или другие признаки, характерные для файловых ответов
        String contentDisposition = response.headers().get("Content-Disposition");
        return contentDisposition != null && contentDisposition.contains("attachment");
    }

    public static String bodyToString(final RequestBody request) {
        if (request == null) {
            return "<empty body>";
        }
        final MediaType mediaType = request.contentType();
        if ("multipart/form-data".equals(mediaType == null ? null : mediaType.type())) {
            return "<multipart/form-data body>";
        }
        try {
            final Buffer buffer = new Buffer();
            request.writeTo(buffer);
            return buffer.readUtf8();
        } catch (final IOException e) {
            return "did not work";
        }
    }
}