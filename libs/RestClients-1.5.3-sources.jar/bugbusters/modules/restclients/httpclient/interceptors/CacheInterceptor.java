package bugbusters.modules.restclients.httpclient.interceptors;

import okhttp3.CacheControl;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;
import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

/**
 * Служит для кэширования GET-запросов.
 * Работает только...
 */
public class CacheInterceptor implements Interceptor {

    @NotNull
    @SuppressWarnings("MustBeClosed")
    @Override
    public Response intercept(@NotNull Chain chain) throws IOException {
        Request request = chain.request();
        if (!isCacheEnabled()) {
            Request newRequest = request.newBuilder()
                    .cacheControl(CacheControl.FORCE_NETWORK)
                    .header("Cache-Control", "no-store")
                    .build();
            return chain.proceed(newRequest);
        }

        // Только для GET
        if (!"GET".equalsIgnoreCase(request.method())) {
            return chain.proceed(request);
        }

        CacheControl cacheControl = new CacheControl.Builder()
                .maxAge(cacheMaxAge(), TimeUnit.SECONDS)
                .maxStale(cacheMaxStale(), TimeUnit.SECONDS)
                .minFresh(cacheMinFresh(), TimeUnit.SECONDS)
                .build();
        Request newRequest = request.newBuilder()
                .header("Cache-Control", cacheControl.toString())
                .build();

        Response response = chain.proceed(newRequest);
        return response.newBuilder()
                .header("Cache-Control", "public, max-age=" + Math.max(1, cacheMaxAge()))  // ax-age=0 - «ответ немедленно устаревает» → кэш может сохранить, но не будет использовать без валидации.
                .build();

    }

    public static boolean isCacheEnabled() {
        return Boolean.parseBoolean(System.getProperty("http.cache", "false"));
    }

    /**
     * Возвращает максимальный размер HTTP-кэша в байтах.
     * Значение задаётся через системное свойство {@code http.cache.size},
     * если не указано — используется значение по умолчанию 500МБ.
     *
     * @return размер кэша в байтах
     */
    public static long cacheSize() {
        return Optional.ofNullable(System.getProperty("http.cache.size"))
                .map(Long::valueOf)
                .orElse(500 * 1024 * 1024L);
    }

    /**
     * Возвращает путь к директории для хранения HTTP-кэша.
     * Значение задаётся через системное свойство {@code http.cache.path},
     * если не указано — используется путь по умолчанию "user.home/http_cache".
     *
     * @return путь к кэшу
     */
    public static File cachePath() {
        return Optional.ofNullable(System.getProperty("http.cache.path"))
                .map(Paths::get)
                .map(Path::toFile)
                .orElse(Paths.get(System.getProperty("user.home"), "http_cache").toFile());
    }

    /**
     * Возвращает максимальное время (в секундах), в течение которого закэшированный ответ
     * считается "свежим" и может быть использован без обращения к серверу.
     *
     * <p>Соответствует HTTP-директиве {@code Cache-Control: max-age=N}.
     *
     * <p>Если значение положительное, OkHttp будет использовать закэшированный ответ
     * для повторных запросов в течение указанного времени, даже если данные на сервере
     * могли измениться. Запрос к серверу выполняться не будет.
     *
     * <p>Пример:
     * <ul>
     *   <li>{@code max-age=3600} — кэш свежий 1 час.</li>
     *   <li>{@code max-age=0} — кэш сразу устаревает, каждый запрос проверяется на сервере.</li>
     * </ul>
     *
     * <p>Значение читается из системного свойства {@code http.cache.maxAge},
     * если не задано — используется значение по умолчанию '0'.
     *
     * @return время в секундах, в течение которого кэш считается свежим
     * @see <a href="https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Cache-Control">Cache-Control</a>
     */
    public static int cacheMaxAge() {
        return Optional.ofNullable(System.getProperty("http.cache.maxAge"))
                .map(Integer::valueOf)
                .orElse(0);
    }

    /**
     * Возвращает максимальное время (в секундах), на которое можно использовать
     * устаревший (stale) кэш, если сервер недоступен (например, в оффлайн-режиме).
     *
     * <p>Соответствует HTTP-директиве {@code Cache-Control: max-stale=N}.
     *
     * <p>Полезно для обеспечения работоспособности приложения при отсутствии сети.
     * Позволяет использовать кэшированные данные даже после истечения {@code max-age},
     * но не дольше указанного времени.
     *
     * <p>Пример:
     * <ul>
     *   <li>{@code max-age=3600, max-stale=7200} — данные свежи 1 час, но ещё 2 часа
     *       могут использоваться при отсутствии сети.</li>
     * </ul>
     *
     * <p>Значение читается из системного свойства {@code http.cache.maxStale},
     * если не задано — используется значение по умолчанию '2 часа'.
     *
     * @return дополнительное время в секундах, разрешающее использование устаревшего кэша
     * @see <a href="https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Cache-Control#max-stale">max-stale</a>
     */
    public static int cacheMaxStale() {
        return Optional.ofNullable(System.getProperty("http.cache.maxStale"))
                .map(Integer::valueOf)
                .orElse((int) Duration.ofHours(2).getSeconds());
    }

    /**
     * Возвращает минимальное время (в секундах), в течение которого ответ должен
     * оставаться свежим после его получения.
     *
     * <p>Соответствует HTTP-директиве {@code Cache-Control: min-fresh=N}.
     *
     * <p>Клиент указывает, что хочет получить ответ, который будет оставаться актуальным
     * как минимум на указанное время. OkHttp не будет использовать кэш, если он
     * станет устаревшим раньше, чем через {@code N} секунд после получения.
     *
     * <p>Используется, когда важно, чтобы данные оставались свежими в течение
     * определённого времени (например, для критичных к актуальности операций).
     *
     * <p>Пример:
     * <ul>
     *   <li>Если {@code min-fresh=600}, а кэшированный ответ станет устаревшим через 5 минут — он НЕ будет использован,
     *       даже если сейчас ещё "свежий".</li>
     * </ul>
     *
     * <p>Значение читается из системного свойства {@code http.cache.minFresh},
     * если не задано — используется значение по умолчанию '0'.
     *
     * @return минимальное время в секундах, в течение которого ответ должен оставаться свежим
     * @see <a href="https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Cache-Control#min-fresh">min-fresh</a>
     */
    public static int cacheMinFresh() {
        return Optional.ofNullable(System.getProperty("http.cache.minFresh"))
                .map(Integer::valueOf)
                .orElse(0);
    }
}
