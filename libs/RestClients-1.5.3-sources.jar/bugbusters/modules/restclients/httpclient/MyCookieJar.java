package bugbusters.modules.restclients.httpclient;

import okhttp3.Cookie;
import okhttp3.CookieJar;
import okhttp3.HttpUrl;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.CookieManager;
import java.net.CookiePolicy;
import java.net.HttpCookie;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static java.util.Collections.emptyList;
import static java.util.Collections.emptyMap;
import static java.util.stream.Collectors.toList;

class MyCookieJar implements CookieJar {
    private static final Logger logger = LoggerFactory.getLogger(MyCookieJar.class);

    private final CookieManager cookieManager = new CookieManager();

    public MyCookieJar() {
        cookieManager.setCookiePolicy(CookiePolicy.ACCEPT_NONE);
    }

    public MyCookieJar(@NotNull final CookiePolicy cookiePolicy) {
        cookieManager.setCookiePolicy(cookiePolicy);
    }

    @NotNull
    public MyCookieJar setCookiePolicy(@NotNull final CookiePolicy cookiePolicy) {
        cookieManager.setCookiePolicy(cookiePolicy);
        return this;
    }

    @NotNull
    public List<HttpCookie> getAllCookies() {
        return cookieManager.getCookieStore().getCookies();
    }

    @NotNull
    @Override
    public List<Cookie> loadForRequest(@NotNull HttpUrl httpUrl) {
        final Map<String, List<String>> cookieHeaders;

        try {
            cookieHeaders = cookieManager.get(httpUrl.uri(), emptyMap());
        } catch (IOException e) {
            logger.warn("Loading cookies failed for " + httpUrl.resolve("/..."));
            return emptyList();
        }

        List<Cookie> cookies = new ArrayList<>();

        cookieHeaders.forEach((key, value) -> {
            if ((key.equals("Cookie") || key.equals("Cookie2")) && !value.isEmpty()) {
                value.forEach(header -> cookies.addAll(decodeHeaderAsCookie(httpUrl, header)));
            }
        });

        return cookies;
    }

    @Override
    public void saveFromResponse(@NotNull HttpUrl httpUrl, @NotNull List<Cookie> cookies) {
        final List<String> cookieStrings = cookies.stream()
                .map(Cookie::toString)
                .collect(toList());

        Map<String, List<String>> t = new HashMap<>();
        t.put("Set-Cookie", cookieStrings);

        try {
            cookieManager.put(httpUrl.uri(), t);
        } catch (IOException e) {
            logger.warn("Loading cookies failed for " + httpUrl.resolve("/..."));
        }
    }

    /**
     * Реализация метода полностью скопирована из JavaNetCookieJar
     */
    private List<Cookie> decodeHeaderAsCookie(HttpUrl url, String header) {
        List<Cookie> result = new ArrayList<>();
        int pos = 0;
        final int limit = header.length();
        int pairEnd;

        while (pos < limit) {
            pairEnd = delimiterOffset(header, ";,", pos, limit);
            int equalsSign = delimiterOffset(header, "=", pos, pairEnd);
            String name = header.substring(pos, equalsSign).trim();
            if (name.startsWith("$")) {
                pos = pairEnd + 1;
                continue;
            }

            String value = (equalsSign < pairEnd) ? header.substring(equalsSign + 1, pairEnd).trim() : "";
            if (value.startsWith("\"") && value.endsWith("\"")) {
                value = value.substring(1, value.length() - 1);
            }

            result.add(new Cookie.Builder()
                    .name(name)
                    .value(value)
                    .domain(url.host())
                    .build());
            pos = pairEnd + 1;
        }

        return result;
    }

    /**
     * utility-метод, находит в строке индекс первого элемента, совпадающего с одним из разделителей
     */
    private int delimiterOffset(String referenceString, String delimiters, int startIndex, int endIndex) {
        assert startIndex < referenceString.length() - 1;
        assert startIndex < endIndex;
        assert endIndex <= referenceString.length();

        int pos = startIndex;
        final char[] delimitersArray = delimiters.toCharArray();

        while (pos < endIndex) {
            final char c = referenceString.charAt(pos);
            for (char delimiter : delimitersArray) {
                if (c == delimiter) return pos;
            }
            ++pos;
        }

        return endIndex;
    }
}
