package impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * Представляет собой одну строку из тестовых данных тест-кейса
 */
public class TestData {
    private final Map<String, String> testDataPairs;

    public TestData(Map<? extends String, ? extends String> m) {
        testDataPairs = Collections.unmodifiableMap(m);
    }

    public String get(String columnName) {
        return testDataPairs.get(columnName);
    }

    public String getOrDefault(String columnName, String defaultValue) {
        return testDataPairs.getOrDefault(columnName, defaultValue);
    }

    public boolean has(String columnName) {
        return testDataPairs.containsKey(columnName);
    }

    public int columnCount() {
        return testDataPairs.size();
    }

    public boolean isEmpty() {
        return testDataPairs.isEmpty();
    }

    public List<String> columnNames() {
        return new ArrayList<>(testDataPairs.keySet());
    }
}
