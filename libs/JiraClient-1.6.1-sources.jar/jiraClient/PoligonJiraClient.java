package jiraClient;

import bugbusters.modules.restclients.httpclient.HttpClient;
import bugbusters.modules.restclients.httpclient.interceptors.CacheInterceptor;
import okhttp3.Cache;
import okhttp3.HttpUrl;

import java.net.CookiePolicy;
import java.util.concurrent.TimeUnit;

import static java.util.Objects.requireNonNull;

public class PoligonJiraClient extends JiraClientBase {

    PoligonJiraClient() {
        super(new PoligonBuilder());
    }

    PoligonJiraClient(PoligonBuilder builder) {
        super(builder);
    }

    @Override
    public String getArtifactoryUrl() {
        return "http://10.1.5.6:8882/";
    }

    @Override
    public String getLogin() {
        return "40svc_jira_atst";
    }

    static class PoligonBuilder extends Builder {

        protected PoligonBuilder() {
            HttpClient.Builder httpClientBuilder = new HttpClient.Builder()
                    .url(requireNonNull(HttpUrl.parse("http://10.1.1.58")))
                    .cookiePolicy(CookiePolicy.ACCEPT_ALL)
                    .followRedirects(false)
                    .followSslRedirects(false)
                    .connectTimeout(60, TimeUnit.SECONDS)
                    .writeTimeout(7, TimeUnit.SECONDS)
                    .readTimeout(7, TimeUnit.SECONDS);

            if (CacheInterceptor.isCacheEnabled())
                httpClientBuilder
                        .cache(new Cache(CacheInterceptor.cachePath(), CacheInterceptor.cacheSize()))
                        .addInterceptor(new CacheInterceptor());

            httpClient = httpClientBuilder.build();
        }

        @Override
        public JiraClient build() {
            return new PoligonJiraClient(this);
        }
    }
}
