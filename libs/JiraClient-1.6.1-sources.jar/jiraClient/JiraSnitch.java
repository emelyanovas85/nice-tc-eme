package jiraClient;

import bugbusters.modules.restclients.httpclient.HttpClient;
import okhttp3.Credentials;
import okhttp3.HttpUrl;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class JiraSnitch {
    public static Optional<JiraClient> getAvailableJira(JiraClient... jiraClients) {
        ExecutorService executor = Executors.newFixedThreadPool(Math.min(jiraClients.length, 10)); // Ограничение на количество потоков

        List<CompletableFuture<JiraClient>> futures = new ArrayList<>();
        for (JiraClient jC : jiraClients) {
            futures.add(
                    CompletableFuture.supplyAsync(() -> jC.isAvailable() ? jC : null, executor));
        }
        // Ожидание первого завершившегося результата
        while (!futures.isEmpty()) {
            Iterator<CompletableFuture<JiraClient>> iterator = futures.iterator();
            while (iterator.hasNext()) {
                CompletableFuture<JiraClient> future = iterator.next();
                if (!future.isDone())
                    continue;
                if (future.join() != null) {
                    // Отмена остальных задач
                    iterator.forEachRemaining(it -> it.cancel(true));
                    executor.shutdownNow();
                    return Optional.ofNullable(future.join());
                }
                iterator.remove();
            }
        }

        executor.shutdown();
        return Optional.empty(); // Если все результаты null
    }

    public static void setCredentialsForJira(JiraClient jiraClient) {
        final String username = System.getProperty("jira.username");
        final String password = System.getProperty("jira.password");

        if (username != null && password != null) {
            jiraClient.getHttpClient().removeStaticHeader("Authorization");
            jiraClient.getHttpClient().addStaticHeader("Authorization", Credentials.basic(username, password));
            return;
        }

        String artifactoryUrl = jiraClient.getArtifactoryUrl();
        HttpClient httpClient = new HttpClient.Builder().url(Objects.requireNonNull(HttpUrl.parse(artifactoryUrl))).build();
        try {
            String pass = httpClient.GET("/artifactory/gradle-release-local/bugbusters/modules/RestClients/hello_world.txt").execute().body().string();
            HttpClient jiraHttpClient = jiraClient.getHttpClient();
            jiraHttpClient.removeStaticHeader("Authorization");
            jiraHttpClient.addStaticHeader("Authorization", Credentials.basic(jiraClient.getLogin(), pass));
        } catch (IOException exception) {
            throw new RuntimeException("Не удалось считать учетные данные из artifactory: " + artifactoryUrl);
        }
    }
}
