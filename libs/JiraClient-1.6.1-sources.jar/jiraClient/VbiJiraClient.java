package jiraClient;

import bugbusters.modules.restclients.httpclient.HttpClient;
import bugbusters.modules.restclients.httpclient.interceptors.CacheInterceptor;
import okhttp3.Cache;
import okhttp3.HttpUrl;

import java.net.CookiePolicy;
import java.util.concurrent.TimeUnit;

import static java.util.Objects.requireNonNull;

public class VbiJiraClient extends JiraClientBase {
    VbiJiraClient() {
        super(new VbiBuilder());
    }

    VbiJiraClient(VbiBuilder builder) {
        super(builder);
    }

    @Override
    public String getArtifactoryUrl() {
        return "http://10.128.89.178:8882/";
    }

    @Override
    public String getLogin() {
        return "40svcANFO";
    }

    static class VbiBuilder extends Builder {

        protected VbiBuilder() {
            HttpClient.Builder httpClientBuilder = new HttpClient.Builder()
                    .url(requireNonNull(HttpUrl.parse("http://s0hjiraas02.vip.cbr.ru:8080")))
                    .cookiePolicy(CookiePolicy.ACCEPT_ALL)
                    .followRedirects(false)
                    .followSslRedirects(false)
                    .connectTimeout(60, TimeUnit.SECONDS)
                    .writeTimeout(7, TimeUnit.SECONDS)
                    .readTimeout(7, TimeUnit.SECONDS);

            if (CacheInterceptor.isCacheEnabled())
                httpClientBuilder
                        .cache(new Cache(CacheInterceptor.cachePath(), CacheInterceptor.cacheSize()))
                        .addInterceptor(new CacheInterceptor());

            httpClient = httpClientBuilder.build();
        }

        @Override
        public JiraClient build() {
            return new VbiJiraClient(this);
        }
    }
}
